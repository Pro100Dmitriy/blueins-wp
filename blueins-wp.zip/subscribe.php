<?php

if( $_POST ){
    $test = $_POST;
    //debug( print_r($test) );
}